import HomePage from "./pages/HomePage";

const routes = [
    { path: "/", name: "홈", component: HomePage, exact: true },
    { path: "/home", name: "홈", component: HomePage, },
];

export default routes;